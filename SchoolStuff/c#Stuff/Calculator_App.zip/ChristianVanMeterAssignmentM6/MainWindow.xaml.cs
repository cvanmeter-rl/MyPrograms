﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ChristianVanMeterAssignmentM6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.X || (e.Key >= Key.D0 && e.Key <= Key.D9))
            {
                var strKey = new KeyConverter().ConvertToString(e.Key);
                TextB.Text += strKey;
            }
            else if (e.Key == Key.OemPlus)
            {
                TextB.Text += "+";
            }
            else if (e.Key == Key.OemMinus)
            {
                TextB.Text += "-";
            }
            else if (e.Key == Key.OemPeriod)
            {
                TextB.Text += ".";
            }
            else if (e.Key == Key.OemQuestion)
            {
                TextB.Text += "/";
            }
            else if (e.Key == Key.Back)
            {
                DeleteChar_Click(sender, e);
            }
            else if (e.Key == Key.Enter)
            {
                CalculatorResult();
            }
            else if (e.Key == Key.F6)
            {
                TextB.Text += "^";
            }
        }
        private void Number_Click(object sender, RoutedEventArgs e)
        {
            if (TextB.Text.Equals("Error"))
            {
                TextB.Text= "";
            }
            Button button = (Button)sender;
            if(!string.IsNullOrEmpty(TextB.Text) && button.Content.ToString().Equals(".") && TextB.Text.Substring(TextB.Text.Length - 1, 1).Equals("."))//makes it so that you cant put two periods back to back
            {

            }
            else
            {
                TextB.Text += button.Content.ToString();
            }
        }

        private void Equal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CalculatorResult();
            }
            catch(Exception ex)
            {
                TextB.Text = "Error Occurred! Clear And Try Again!";
            }
        }
        private void CalculatorResult()
        {
            int opIndex = 0;
            if(string.IsNullOrEmpty(TextB.Text))
            {
                //do nothing because nothing has been input
            }
            else
            {
                try
                {
                    if (TextB.Text.Contains("+"))
                    {
                        opIndex = TextB.Text.IndexOf("+");
                    }
                    else if (TextB.Text.Contains("X"))
                    {
                        opIndex = TextB.Text.IndexOf("X");
                    }
                    else if (TextB.Text.Contains("/"))
                    {
                        opIndex = TextB.Text.IndexOf("/");
                    }
                    else if (TextB.Text.Contains("^"))
                    {
                        opIndex = TextB.Text.IndexOf("^");
                    }
                    else if (TextB.Text.Contains("-"))
                    {
                        opIndex = TextB.Text.IndexOf("-");
                        if (opIndex == 0)
                        {
                            opIndex = TextB.Text.IndexOf("-", opIndex + 1);
                        }
                    }
                    String operand;
                    operand = TextB.Text.Substring(opIndex, 1);
                    double first = Convert.ToDouble(TextB.Text.Substring(0, opIndex));
                    double second = Convert.ToDouble(TextB.Text.Substring(opIndex + 1, TextB.Text.Length - 1 - opIndex));


                    if (operand == "-")
                    {
                        TextB.Text = (first - second).ToString();
                    }
                    else if (operand == "+")
                    {
                        TextB.Text = (first + second).ToString();
                    }
                    else if (operand == "/")
                    {
                        if (second == 0 || second == 0.0)
                        {
                            TextB.Text = "Error";
                        }
                        else
                        {
                            TextB.Text = (first / second).ToString();
                        }
                    }
                    else if (operand == "X")
                    {
                        TextB.Text = (first * second).ToString();
                    }
                    else if(operand == "^") {
                        TextB.Text = (Math.Pow(first,second)).ToString();
                    }
                }
                catch (Exception ex)
                {
                    TextB.Text = "Error Occurred! Clear And Try Again!";
                }
            }

        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            TextB.Text = "";
        }

        private void DeleteChar_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(TextB.Text))
            {
                TextB.Text = TextB.Text.Substring(0,TextB.Text.Length - 1);
            }
        }
    }
}
