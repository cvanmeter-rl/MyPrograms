﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristianVanMeterFinal
{
    [Serializable]
    class store
    {
        //fields for store
        private string name;
        private string address;
        //store should be 4 digits
        private int storeNum = 0000; 
        List<employee> employeeList = new List<employee>();
        List<item> itemList = new List<item>();

        public store(string name, string address,int storeNum)
        {
            this.name = name;
            this.address = address;
            this.storeNum = storeNum;
            this.storeNum = storeNum;
        }
        //properties for store 
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public int StoreNum { 
            get {  return storeNum; } 
            set {  storeNum = value; } 
        }
        public void sortEmp()
        {
            employeeList.Sort((a, b) =>
            {
                var ret = a.LastName.CompareTo(b.LastName);
                if (ret == 0) ret = a.FirstName.CompareTo(b.FirstName);
                return ret;
            });
        }
        public void sortItems()
        {
            itemList.Sort((a, b) =>
            {
                var ret = a.Name.CompareTo(b.Name);
                return ret;
            });
        }
        public void addEmp(employee e)
        {
            employeeList.Add(e);
        }
        public int EmpSize()
        {
            return employeeList.Count;
        }
        public int ItemSize()
        {
            return itemList.Count;
        }
        public employee getEmp(int index)
        {
            return employeeList[index];
        }
        public void removeEmp(employee e)
        {
            employeeList.Remove(e);
        }
        public void addItem(item e)
        {
            itemList.Add(e);
        }
        public item getItem(int index)
        {
            return itemList[index];
        }
        public void removeItem(item e)
        {
            itemList.Remove(e);
        }
    }
}
