﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristianVanMeterFinal
{
    [Serializable]
    class item
    {
        //fields for item
        private string name;
        private string department;
        private string brand;
        private double price = 0.0;
        private int quantity = 0;
        //constructor for item
        public item(string name, string department, string brand, double price,int quantity)
        {
            this.name = name;
            this.department = department;
            this.brand = brand;
            this.price = price;
            this.quantity = quantity;
        }
        //properties for item
        public string Brand
        {
            get { return this.brand; }
            set { this.brand = value; }
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public string Department
        {
            get { return this.department; }
            set { this.department = value; }
        }
        public double Price
        {
            get { return this.price; }
            set { this.price = value; }
        }
        public int Quantity
        {
            get { return this.quantity; }
            set { this.quantity = value; }
        }

    }
}
