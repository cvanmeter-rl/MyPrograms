﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristianVanMeterFinal
{
    [Serializable]
    class employee
    {
        //values for employee
        private string firstName;
        private string lastName;
        private string phoneNum;
        private string gender;
        private string position;
        private double hourlyPay = 0.0;
        private double paycheckTotal = 0.0;
        private double hours = 0.0;
        //constructor for input for employee
        public employee(string firstName,string lastName,string phoneNum,string gender,string position,double hourlyPay,double paycheckTotal,double hours)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNum = phoneNum;
            this.gender = gender;
            this.position = position;
            this.hourlyPay = hourlyPay;
            this.paycheckTotal = paycheckTotal;
            this.hours = hours;
            paycheck();

        }
        public void paycheck()
        {
            paycheckTotal = hourlyPay * hours;
        }
        //properties for each field for employee
        public double Hours
        {
            get { return hours; }
            set { this.hours = value; }
        }

        public string FirstName
        {
            get { return this.firstName; }
            set { this.firstName = value; }
        }
        public string LastName
        {
            get { return this.lastName; }
            set { this.lastName = value; }
        }
        public string PhoneNum
        {
            get { return this.phoneNum; }
            set { this.phoneNum = value; }
        }
        public string Gender
        {
            get { return this.gender; }
            set { this.gender = value; }
        }
        public string Position
        {
            get { return this.position; }
            set { this.position = value; }
        }
        public double PaycheckTotal
        {
            get { return this.paycheckTotal; }
            set { this.paycheckTotal = value; }
        }
        public double HourlyPay
        {
            get { return this.hourlyPay; }
            set { this.hourlyPay = value;}
        }
    }
}
