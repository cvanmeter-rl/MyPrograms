﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristianVanMeterFinal
{
    [Serializable]
    class manager:employee
    {
        //safe code that consists of 4 digits
        private int storeSafeCode = 0000;
        //constructor for creating manager
        public manager(string firstName, string lastName, string phoneNum, string gender, string position, double hourlyPay, double paycheckTotal,double hours,int storeSafeCode):base(firstName,lastName, phoneNum, gender, position,hourlyPay, paycheckTotal,hours)
        {
            this.storeSafeCode = storeSafeCode;
        }
        //property for store safe code
        public int StoreSafeCode
        {
            get { return storeSafeCode; }
            set { this.storeSafeCode = value;}
        }
    }
}
