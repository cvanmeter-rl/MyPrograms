﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace ChristianVanMeterFinal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<store> stores = new List<store>();
        public MainWindow()
        {
            InitializeComponent();

        }
        private void StoreListListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(StoreListListBox.SelectedIndex == -1)//if nothing is selected
            {

            }
            else
            {
                //sets the fields for store if a store is selected
                StoreNameTextBox.Text = stores[StoreListListBox.SelectedIndex].Name;
                StoreAddressTextBox.Text = stores[StoreListListBox.SelectedIndex].Address;
                StoreNumberTextBox.Text = stores[StoreListListBox.SelectedIndex].StoreNum.ToString();
                displayEmployees();
                clearEmployeeFields();

                showItems();
                clearItemFields();

            }
        }
        private void RemoveStoreButton_Click(object sender, RoutedEventArgs e)
        {
            if(StoreListListBox.SelectedIndex == -1)//if no entry is selected
            {

            }
            else
            {
                stores.RemoveAt(StoreListListBox.SelectedIndex);//removes selected entry
                //updates the list box when an entry is removed
                showStoresOnList();
                EmployeeListListBox.Items.Clear();
                clearEmployeeFields();
                //clears store fields
                StoreNameTextBox.Clear();
                StoreAddressTextBox.Clear();
                StoreNumberTextBox.Clear();
            }
        }

        private void AddStoreButton_Click(object sender, RoutedEventArgs e)
        {
            //checks for blank or empty fields
            if(string.IsNullOrEmpty(StoreNameTextBox.Text) || string.IsNullOrEmpty(StoreAddressTextBox.Text) || string.IsNullOrEmpty(StoreNumberTextBox.Text))
            {
                invalidInput("One Or More Fields Were Left Empty! Please Fill In All Fields!");
            }
            else
            {
                //checks if letters are input for store number
                if(StoreNumberTextBox.Text.Any(Char.IsLetter))
                {
                    invalidInput("Invalid Store Number Input! No Letters Allowed For Store Number!");
                }
                else if(StoreNumberTextBox.Text.Length != 4)//checks if store number isnt exactly 4 digits
                {
                    invalidInput("Store Number Must Be 4 Digits Long!");
                }
                else
                {
                    int storeNum = int.Parse(StoreNumberTextBox.Text);
                    if(stores.Count == 0)//if this is the first entry
                    {
                        ListBoxItem storeListBox = new ListBoxItem();
                        store s = new store(StoreNameTextBox.Text, StoreAddressTextBox.Text, storeNum);
                        storeListBox.Content = s.Name + "-" + s.StoreNum.ToString("0000") + ":" + s.Address;
                        stores.Add(s);
                        StoreListListBox.Items.Add(storeListBox);

                    }
                    else//handles when there is multiple entries and sorts based on store name
                    {
                        store s = new store(StoreNameTextBox.Text, StoreAddressTextBox.Text, storeNum);
                        stores.Add(s);
                        stores.Sort((a, b) =>
                        {
                            var ret = a.Name.CompareTo(b.Name);
                            return ret;
                        });
                        showStoresOnList();
                    }
                    StoreNameTextBox.Clear();
                    StoreAddressTextBox.Clear();
                    StoreNumberTextBox.Clear();

                }
            }
        }

        private void AddEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if(StoreListListBox.SelectedIndex == -1)//checks that a store is selected
            {
                invalidInput("A Store Must Be Selected To Add An Employee!");
            }
            else if(string.IsNullOrEmpty(FirstNameTextBox.Text) || string.IsNullOrEmpty(LastNameTextBox.Text) || string.IsNullOrEmpty(PhoneNumTextBox.Text) || string.IsNullOrEmpty(HourlyPayTextBox.Text) || string.IsNullOrEmpty(HoursTextBox.Text))
            {
                invalidInput("One Or More Fields Were Left Empty! Please Fill In All Fields!");
            }
            else if(FirstNameTextBox.Text.Any(Char.IsDigit) || LastNameTextBox.Text.Any(Char.IsDigit))//checks for numbers in first and last name
            {
                invalidInput("First And Last Name Can't Contain Numbers!");
            }
            else if(PhoneNumTextBox.Text.Any(Char.IsLetter))//checks for letters in phone number
            {
                invalidInput("Phone Number Can't Contain Letters!");
            }
            else
            {
                if(HourlyPayTextBox.Text.Any(Char.IsLetter) || HourlyPayTextBox.Text.Contains('$'))//checks for invalid input
                {
                    invalidInput("Invalid Hourly Pay Input! No Letters Allowed For Hourly Pay!");
                }
                else if(HoursTextBox.Text.Any(Char.IsLetter))
                {
                    invalidInput("Invalid Hours Input! No Letters Allowed For Hours!");
                }
                else
                {
                    if (PositionComboBox.SelectedIndex == 0)//for employee
                    {
                        employee emp = new employee(FirstNameTextBox.Text, LastNameTextBox.Text, PhoneNumTextBox.Text, GenderComboBox.Text,"Employee", Double.Parse(HourlyPayTextBox.Text), 0.0, Double.Parse(HoursTextBox.Text));
                        stores[StoreListListBox.SelectedIndex].addEmp(emp);
                          
                        if (stores[StoreListListBox.SelectedIndex].EmpSize() == 1)//if this is the first inserted entry
                        {
                            ListBoxItem empListBox = new ListBoxItem();
                            empListBox.Content = emp.LastName + "," + emp.FirstName + ":" + emp.PhoneNum + "|" + emp.Gender + "," + emp.Position + "| Hourly Pay: " + emp.HourlyPay + "| Hours Worked:" + emp.Hours; 
                            EmployeeListListBox.Items.Add(empListBox);

                        }
                        else//handles situation when we have multiple entries
                        {
                            stores[StoreListListBox.SelectedIndex].sortEmp();
                            displayEmployees();
                        }
                        clearEmployeeFields();

                    }
                    else if (PositionComboBox.SelectedIndex == 1)//for manager
                    {
                        if(SafeCodeTextBox.Text.Any(Char.IsLetter))//invalid store safe code input
                        {
                            invalidInput("Safe Code Can Not Contain Letters!");
                        }
                        else if(SafeCodeTextBox.Text.Length != 4)
                        {
                            invalidInput("Safe Code Must Be 4 Digits Long!");
                        }
                        else
                        {
                            int safeCode = int.Parse(SafeCodeTextBox.Text);
                            manager m = new manager(FirstNameTextBox.Text, LastNameTextBox.Text, PhoneNumTextBox.Text, GenderComboBox.Text, "Manager", Double.Parse(HourlyPayTextBox.Text), 0.0, Double.Parse(HoursTextBox.Text), safeCode);
                            stores[StoreListListBox.SelectedIndex].addEmp(m);
                            if (stores[StoreListListBox.SelectedIndex].EmpSize() == 1)//if this is the first inserted entry
                            {
                                ListBoxItem manListBox = new ListBoxItem();
                                manListBox.Content = m.LastName + "," + m.FirstName + ":" + m.PhoneNum + "|" + m.Gender + "," + m.Position + "| Hourly Pay: " + m.HourlyPay + "| Hours Worked:" + m.Hours + "| Safe Code:" + m.StoreSafeCode.ToString("0000");
                                EmployeeListListBox.Items.Add(manListBox);
                            }
                            else
                            {
                                stores[StoreListListBox.SelectedIndex].sortEmp();
                                displayEmployees();
                            }
                            clearEmployeeFields();
                        }
                    }
                    else if (PositionComboBox.SelectedIndex == 2)//for store owner
                    {
                        if (SafeCodeTextBox.Text.Any(Char.IsLetter))//invalid store safe code input
                        {
                            invalidInput("Safe Code Can Not Contain Letters!");
                        }
                        else if (SafeCodeTextBox.Text.Length != 4)
                        {
                            invalidInput("Safe Code Must Be 4 Digits Long!");
                        }
                        else if(OverwriteCodeTextBox.Text.Any(Char.IsLetter))//invalid overwrite code input
                        {
                            invalidInput("Overwrite Code Can Not Contain Letters!");
                        }
                        else if(OverwriteCodeTextBox.Text.Length != 6)
                        {
                            invalidInput("Overwrite Code Must Be 6 Digits Long!");
                        }
                        else
                        {
                            int safeCode = int.Parse(SafeCodeTextBox.Text);
                            int overwriteCode = int.Parse(OverwriteCodeTextBox.Text);
                            storeOwner s = new storeOwner(FirstNameTextBox.Text, LastNameTextBox.Text, PhoneNumTextBox.Text, GenderComboBox.Text, "Manager", Double.Parse(HourlyPayTextBox.Text), 0.0, Double.Parse(HoursTextBox.Text), safeCode,overwriteCode);
                            stores[StoreListListBox.SelectedIndex].addEmp(s);
                            if (stores[StoreListListBox.SelectedIndex].EmpSize() == 1)//if this is the first entry
                            {
                                ListBoxItem soListBox = new ListBoxItem();
                                soListBox.Content = s.LastName + "," + s.FirstName + ":" + s.PhoneNum + "|" + s.Gender + "," + s.Position + "| Hourly Pay: " + s.HourlyPay + "| Hours Worked:" + s.Hours + "| Safe Code:" + safeCode.ToString("0000") + "| Overwrite Code: " + overwriteCode.ToString("000000");
                                EmployeeListListBox.Items.Add(soListBox);
                            }
                            else//if there is more than 1 entry 
                            {
                                stores[StoreListListBox.SelectedIndex].sortEmp();
                                displayEmployees();
                            }
                            clearEmployeeFields();
                        }
                    }
                }
            }
        }
        //this function clears all employee fields
        public void clearEmployeeFields()
        {
            FirstNameTextBox.Clear();
            LastNameTextBox.Clear();
            PhoneNumTextBox.Clear();
            GenderComboBox.SelectedIndex = 0;
            PositionComboBox.SelectedIndex = 0;
            HourlyPayTextBox.Clear();
            HoursTextBox.Clear();
            PaycheckTextBox.Clear();
            SafeCodeTextBox.Clear();
            OverwriteCodeTextBox.Clear();
        }
        private void EditEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeListListBox.SelectedIndex == -1)//not a valid selection
            {

            }
            else
            {
                if (string.IsNullOrEmpty(FirstNameTextBox.Text) || string.IsNullOrEmpty(LastNameTextBox.Text) || string.IsNullOrEmpty(PhoneNumTextBox.Text) || string.IsNullOrEmpty(HourlyPayTextBox.Text) || string.IsNullOrEmpty(HoursTextBox.Text))
                {
                    invalidInput("One Or More Fields Were Left Empty! Please Fill In All Fields!");
                }
                else
                {
                    if (HourlyPayTextBox.Text.Any(Char.IsLetter) || HourlyPayTextBox.Text.Contains('$'))//checks for invalid input
                    {
                        invalidInput("Invalid Hourly Pay Input! No Letters Allowed For Hourly Pay!");
                    }
                    else if (HoursTextBox.Text.Any(Char.IsLetter))
                    {
                        invalidInput("Invalid Hours Input! No Letters Allowed For Hours!");
                    }
                    else if(FirstNameTextBox.Text.Any(Char.IsDigit) || LastNameTextBox.Text.Any(Char.IsDigit))//checks for numbers in first and last name
            {
                invalidInput("First And Last Name Can't Contain Numbers!");
            }
            else if(PhoneNumTextBox.Text.Any(Char.IsLetter))//checks for letters in phone number
            {
                invalidInput("Phone Number Can't Contain Letters!");
            }
                    else
                    {
                        if (PositionComboBox.SelectedIndex == 0) //for employee
                        {
                            //checks if any fields have been changed and if so update the info
                            employee emp = stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);
                            if (emp.FirstName.CompareTo(FirstNameTextBox.Text) != 0)
                            {
                                emp.FirstName = FirstNameTextBox.Text;
                            }
                            if(emp.LastName.CompareTo(LastNameTextBox.Text)!=0)
                            {
                                emp.LastName = LastNameTextBox.Text;
                            }
                            if(emp.PhoneNum.CompareTo(PhoneNumTextBox.Text)!=0)
                            {
                                emp.PhoneNum = PhoneNumTextBox.Text;
                            }
                            if(emp.Gender.CompareTo(GenderComboBox.Text)!=0)
                            {
                                emp.Gender = GenderComboBox.Text;
                            }
                            if (emp.HourlyPay.ToString().CompareTo(HourlyPayTextBox.Text) != 0)
                            {
                                emp.HourlyPay = Double.Parse(HourlyPayTextBox.Text);
                                emp.paycheck();
                            }
                            if (emp.Hours.ToString().CompareTo(HoursTextBox.Text) != 0)
                            {
                                emp.Hours = Double.Parse(HoursTextBox.Text);
                                emp.paycheck();
                            }
                            
                        }
                        else if (PositionComboBox.SelectedIndex == 1)//for manager
                        {
                            if (SafeCodeTextBox.Text.Any(Char.IsLetter))//invalid store safe code input
                            {
                                invalidInput("Safe Code Can Not Contain Letters!");
                            }
                            else if (SafeCodeTextBox.Text.Length != 4)
                            {
                                invalidInput("Safe Code Must Be 4 Digits Long!");
                            }
                            else
                            {
                                //checks if any fields have been changed and if so update the info
                                manager m = (manager)stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);

                                if (m.FirstName.CompareTo(FirstNameTextBox.Text) != 0)
                                {
                                    m.FirstName = FirstNameTextBox.Text;
                                }
                                if (m.LastName.CompareTo(LastNameTextBox.Text) != 0)
                                {
                                    m.LastName = LastNameTextBox.Text;
                                }
                                if (m.PhoneNum.CompareTo(PhoneNumTextBox.Text) != 0)
                                {
                                    m.PhoneNum = PhoneNumTextBox.Text;
                                }
                                if (m.Gender.CompareTo(GenderComboBox.Text) != 0)
                                {
                                    m.Gender = GenderComboBox.Text;
                                }
                                if (m.HourlyPay.ToString().CompareTo(HourlyPayTextBox.Text) != 0)
                                {
                                    m.HourlyPay = Double.Parse(HourlyPayTextBox.Text);
                                    m.paycheck();
                                }
                                if (m.Hours.ToString().CompareTo(HoursTextBox.Text) != 0)
                                {
                                    m.Hours = Double.Parse(HoursTextBox.Text);
                                    m.paycheck();
                                }
                                int code = int.Parse(SafeCodeTextBox.Text);
                                if(m.StoreSafeCode.CompareTo(code) != 0)
                                {
                                    m.StoreSafeCode = code;
                                }                               
                            }
                        }
                        else//for store owner
                        {
                            if (SafeCodeTextBox.Text.Any(Char.IsLetter))//invalid store safe code input
                            {
                                invalidInput("Safe Code Can Not Contain Letters!");
                            }
                            else if (SafeCodeTextBox.Text.Length != 4)
                            {
                                invalidInput("Safe Code Must Be 4 Digits Long!");
                            }
                            else if (OverwriteCodeTextBox.Text.Any(Char.IsLetter))//invalid overwrite code input
                            {
                                invalidInput("Overwrite Code Can Not Contain Letters!");
                            }
                            else if (OverwriteCodeTextBox.Text.Length != 6)
                            {
                                invalidInput("Overwrite Code Must Be 6 Digits Long!");
                            }
                            else
                            {
                                //checks if any fields have been changed and if so update the info
                                storeOwner s = (storeOwner)stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);
                                if (s.FirstName.CompareTo(FirstNameTextBox.Text) != 0)
                                {
                                    s.FirstName = FirstNameTextBox.Text;
                                }
                                if (s.LastName.CompareTo(LastNameTextBox.Text) != 0)
                                {
                                    s.LastName = LastNameTextBox.Text;
                                }
                                if (s.PhoneNum.CompareTo(PhoneNumTextBox.Text) != 0)
                                {
                                    s.PhoneNum = PhoneNumTextBox.Text;
                                }
                                if (s.Gender.CompareTo(GenderComboBox.Text) != 0)
                                {
                                    s.Gender = GenderComboBox.Text;
                                }
                                if (s.HourlyPay.ToString().CompareTo(HourlyPayTextBox.Text) != 0)
                                {
                                    s.HourlyPay = Double.Parse(HourlyPayTextBox.Text);
                                    s.paycheck();
                                }
                                if (s.Hours.ToString().CompareTo(HoursTextBox.Text) != 0)
                                {
                                    s.Hours = Double.Parse(HoursTextBox.Text);
                                    s.paycheck();
                                }
                                int code = int.Parse(SafeCodeTextBox.Text);
                                if (s.StoreSafeCode.CompareTo(code) != 0)
                                {
                                    s.StoreSafeCode = code;
                                }
                                code = int.Parse(OverwriteCodeTextBox.Text);
                                if(s.OverwriteCode.CompareTo(code) != 0)
                                {
                                    s.OverwriteCode = code;
                                }

                            }
                        }
                    }
                    clearEmployeeFields();
                    stores[StoreListListBox.SelectedIndex].sortEmp();
                    displayEmployees();
                }
            }
        }
        private void EmployeeListListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(EmployeeListListBox.SelectedIndex == -1)//not a valid item selected
            {

            }
            else//fills out the fields when a entry is clicked
            {
                if(stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex) is storeOwner)//if the selected employee is a storeOwner
                {
                    storeOwner s = (storeOwner)stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);

                    FirstNameTextBox.Text = s.FirstName;
                    LastNameTextBox.Text = s.LastName;
                    PhoneNumTextBox.Text = s.PhoneNum;
                    if (s.Gender.CompareTo("Male") == 0)
                    {
                        GenderComboBox.SelectedIndex = 0;
                    }
                    else if (s.Gender.CompareTo("Female") == 0)
                    {
                        GenderComboBox.SelectedIndex = 1;
                    }
                    else
                    {
                        GenderComboBox.SelectedIndex = 2;
                    }
                    PositionComboBox.SelectedIndex = 2;
                    HourlyPayTextBox.Text = s.HourlyPay.ToString();
                    HoursTextBox.Text = s.Hours.ToString();
                    PaycheckTextBox.Text = s.PaycheckTotal.ToString();
                    SafeCodeTextBox.Text = s.StoreSafeCode.ToString();
                    OverwriteCodeTextBox.Text = s.OverwriteCode.ToString();
                }
                else if(stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex) is manager)//if the selected employee is a manager
                {
                    manager m = (manager)stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);
                    
                    FirstNameTextBox.Text = m.FirstName;
                    LastNameTextBox.Text = m.LastName;
                    PhoneNumTextBox.Text = m.PhoneNum;
                    if (m.Gender.CompareTo("Male") == 0)
                    {
                        GenderComboBox.SelectedIndex = 0;
                    }
                    else if (m.Gender.CompareTo("Female") == 0)
                    {
                        GenderComboBox.SelectedIndex = 1;
                    }
                    else
                    {
                        GenderComboBox.SelectedIndex = 2;
                    }
                    PositionComboBox.SelectedIndex = 1;
                    HourlyPayTextBox.Text = m.HourlyPay.ToString();
                    HoursTextBox.Text = m.Hours.ToString();
                    PaycheckTextBox.Text = m.PaycheckTotal.ToString();
                    SafeCodeTextBox.Text = m.StoreSafeCode.ToString();
                }
                else//if the selected employee is a employee
                {
                    employee emp = stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex);
                    FirstNameTextBox.Text = emp.FirstName;
                    LastNameTextBox.Text = emp.LastName;
                    PhoneNumTextBox.Text = emp.PhoneNum;
                    if(emp.Gender.CompareTo("Male") == 0)
                    {
                        GenderComboBox.SelectedIndex = 0;
                    }
                    else if(emp.Gender.CompareTo("Female") == 0)
                    {
                        GenderComboBox.SelectedIndex = 1;
                    }
                    else
                    {
                        GenderComboBox.SelectedIndex = 2;
                    }
                    PositionComboBox.SelectedIndex = 0;
                    HourlyPayTextBox.Text = emp.HourlyPay.ToString();
                    HoursTextBox.Text = emp.Hours.ToString();
                    PaycheckTextBox.Text = emp.PaycheckTotal.ToString();
                }
            }
        }
        private void RemoveEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if(EmployeeListListBox.SelectedIndex == -1)//not a valid item selected
            {

            }
            else
            {
                //handles an employee being removed and updates the employee list box
                stores[StoreListListBox.SelectedIndex].removeEmp(stores[StoreListListBox.SelectedIndex].getEmp(EmployeeListListBox.SelectedIndex));
                displayEmployees();
                clearEmployeeFields();
            }

            
        }

        private void AddItemButton_Click(object sender, RoutedEventArgs e)
        {
            if(StoreListListBox.SelectedIndex == -1)//if a store isnt selected
            {
                invalidInput("A Store Must Be Selected To Add An Item!");
            }
            else if(string.IsNullOrEmpty(ItemNameTextBox.Text) || string.IsNullOrEmpty(DepartmentTextBox.Text) || string.IsNullOrEmpty(BrandTextBox.Text) || string.IsNullOrEmpty(PriceTextBox.Text) || string.IsNullOrEmpty(QuantityTextBox.Text))//checks for empty entry
            {
                invalidInput("One Or More Fields Left Empty!");
            }
            else if(PriceTextBox.Text.Any(Char.IsLetter) || QuantityTextBox.Text.Any(Char.IsLetter))//if a character is inserted for price or quantity
            {
                invalidInput("Price And Quantity Can't Contain Characters!");
            }
            else
            {
                double price = Double.Parse(PriceTextBox.Text);
                double quantity = Double.Parse(QuantityTextBox.Text);
                if(Math.Floor(quantity) != quantity)//checks if a decimal value is inserted for quantity
                {
                    invalidInput("Quantity Must Be An Integer!");
                }
                else
                {
                    item i = new item(ItemNameTextBox.Text, DepartmentTextBox.Text, BrandTextBox.Text, price,(int)quantity);
                    stores[StoreListListBox.SelectedIndex].addItem(i);//adds and displays info onto list
                    stores[StoreListListBox.SelectedIndex].sortItems();
                    showItems();

                    clearItemFields();//clear fields
                   
                }
               
            }
        }

        private void RemoveItemButton_Click(object sender, RoutedEventArgs e)
        {
            if(ItemListBox.SelectedIndex == -1)//valid item not selected
            {

            }
            else
            {
                if(string.IsNullOrEmpty(RemoveTextBox.Text))//if quantity to remove is empty
                {
                    //removes item
                    stores[StoreListListBox.SelectedIndex].removeItem(stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex));
                    showItems();
                    clearItemFields();
                }
                else
                {  
                    if(RemoveTextBox.Text.Any(Char.IsLetter))//invalid quantity input
                    {
                        invalidInput("Quantity To Remove Must Not Contain Letters!");
                    }
                    else if (Math.Floor(Double.Parse(RemoveTextBox.Text)) != Double.Parse(RemoveTextBox.Text))
                    {
                        invalidInput("Quantity To Remove Must Not Contain Decimal Values!");
                    }
                    else
                    {
                        double removeNum = Double.Parse(RemoveTextBox.Text);
                        if ((int)removeNum > stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex).Quantity)//if too large of a value is requested to be removed
                        {
                            invalidInput("You Are Trying To Remove More Items Than The Quantity Of Items Present!");
                        }
                        else if((int)removeNum == stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex).Quantity)//removing all of the items present
                        {
                            //removes item
                            stores[StoreListListBox.SelectedIndex].removeItem(stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex));
                            showItems();
                            clearItemFields();
                        }
                        else
                        {
                            //reduces quantity of item and updates UI
                            stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex).Quantity = stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex).Quantity - (int)removeNum;
                            showItems();
                            clearItemFields();

                        }
                    }
                }
            }
        }
        private void ItemListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(ItemListBox.SelectedIndex == -1)//nothing selected
            {

            }
            else
            {
                //displays the item info in the fields if a item is selected
                item i = stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex);
                ItemNameTextBox.Text = i.Name;
                DepartmentTextBox.Text = i.Department;
                BrandTextBox.Text = i.Brand;
                PriceTextBox.Text = i.Price.ToString();
                QuantityTextBox.Text = i.Quantity.ToString();

            }
        }
        private void EditItemButton_Click(object sender, RoutedEventArgs e)
        {
            if(ItemListBox.SelectedIndex != -1)//valid item selected
            {
                if (string.IsNullOrEmpty(ItemNameTextBox.Text) || string.IsNullOrEmpty(DepartmentTextBox.Text) || string.IsNullOrEmpty(BrandTextBox.Text) || string.IsNullOrEmpty(PriceTextBox.Text) || string.IsNullOrEmpty(QuantityTextBox.Text))//checks for empty entry
                {
                    invalidInput("One Or More Fields Left Empty!");
                }
                else if (PriceTextBox.Text.Any(Char.IsLetter) || QuantityTextBox.Text.Any(Char.IsLetter) || PriceTextBox.Text.Contains('$'))//if a character is inserted for price or quantity
                {
                    invalidInput("Price And Quantity Can't Contain Characters!");
                }
                else
                {
                    
                    double quantity = Double.Parse(QuantityTextBox.Text);
                    if (Math.Floor(quantity) != quantity)//checks if a decimal value is inserted for quantity
                    {
                        invalidInput("Quantity Must Be An Integer!");
                    }
                    else
                    {
                        item i = stores[StoreListListBox.SelectedIndex].getItem(ItemListBox.SelectedIndex);
                        //checks if any fields were changed and if so update the item information
                        if (ItemNameTextBox.Text.CompareTo(i.Name) != 0)
                        {
                            i.Name = ItemNameTextBox.Text;
                        }
                        if (DepartmentTextBox.Text.CompareTo(i.Department) != 0)
                        {
                            i.Department = DepartmentTextBox.Text;
                        }
                        if (BrandTextBox.Text.CompareTo(i.Brand) != 0)
                        {
                            i.Brand = BrandTextBox.Text;
                        }
                        double price = Double.Parse(PriceTextBox.Text);
                        if (price.CompareTo(i.Price) != 0)
                        {
                            i.Price = price;
                        }
                        int q = (int)quantity;
                        if (q.CompareTo(i.Quantity) != 0)
                        {
                            i.Quantity = (int)quantity;
                        }

                        clearItemFields();
                        stores[StoreListListBox.SelectedIndex].sortItems();
                        showItems();
                    }
                }
            }
        }
        //clears item fields
        public void clearItemFields()
        {
            ItemNameTextBox.Clear();
            DepartmentTextBox.Clear();
            BrandTextBox.Clear();
            PriceTextBox.Clear();
            QuantityTextBox.Clear();
            RemoveTextBox.Clear();
        }
        //this function displays every item to the item list box
        public void showItems()
        {
            ItemListBox.Items.Clear();
            for(int i = 0;i < stores[StoreListListBox.SelectedIndex].ItemSize();i++)
            {
                item j = stores[StoreListListBox.SelectedIndex].getItem(i);
                ListBoxItem listBox = new ListBoxItem();
                listBox.Content = "Item Name: " + j.Name + "| Quantity: " + j.Quantity + "| Price: " + j.Price + "| Brand: " + j.Brand + "| Department: " + j.Department;
                ItemListBox.Items.Add(listBox);
            }
        }
        //creates a pop up when a error or invalid input is entered
        public void invalidInput(string input)//creates a pop-up when invalid input is given
        {
            System.Windows.Forms.MessageBox.Show(input,"Input",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
        public void showStoresOnList()//displays the store info 
        {
            StoreListListBox.Items.Clear();
            for (int i = 0; i < stores.Count; i++)
            {
                ListBoxItem listBoxItem = new ListBoxItem();
                listBoxItem.Content = stores[i].Name + "-" + stores[i].StoreNum.ToString("0000") + ":" + stores[i].Address;
                StoreListListBox.Items.Add(listBoxItem);
            }
        }
        //this displays the employees' info to the employee list box
        public void displayEmployees()
        {
            EmployeeListListBox.Items.Clear();
            for (int i = 0; i < stores[StoreListListBox.SelectedIndex].EmpSize(); i++)
            {
                if (stores[StoreListListBox.SelectedIndex].getEmp(i) is storeOwner)
                {
                    storeOwner s = (storeOwner)stores[StoreListListBox.SelectedIndex].getEmp(i);
                    ListBoxItem soListBox = new ListBoxItem();
                    soListBox.Content = s.LastName + "," + s.FirstName + ":" + s.PhoneNum + "|" + s.Gender + "," + s.Position + "| Hourly Pay: " + s.HourlyPay + "| Hours Worked:" + s.Hours + "| Safe Code:" + s.StoreSafeCode.ToString("0000") + "| Overwrite Code: " + s.OverwriteCode.ToString("000000");
                    EmployeeListListBox.Items.Add(soListBox);

                }
                else if (stores[StoreListListBox.SelectedIndex].getEmp(i) is manager)
                {
                    manager m = (manager)stores[StoreListListBox.SelectedIndex].getEmp(i);
                    ListBoxItem manListBox = new ListBoxItem();
                    manListBox.Content = m.LastName + "," + m.FirstName + ":" + m.PhoneNum + "|" + m.Gender + "," + m.Position + "| Hourly Pay: " + m.HourlyPay + "| Hours Worked:" + m.Hours + "| Safe Code:" + m.StoreSafeCode.ToString("0000");
                    EmployeeListListBox.Items.Add(manListBox);
                }
                else
                {
                    employee emp = stores[StoreListListBox.SelectedIndex].getEmp(i);
                    ListBoxItem listBox = new ListBoxItem();
                    listBox.Content = emp.LastName + "," + emp.FirstName + ":" + emp.PhoneNum + "|" + emp.Gender + "," + emp.Position + "| Hourly Pay: " + emp.HourlyPay + "| Hours Worked:" + emp.Hours + "|";
                    EmployeeListListBox.Items.Add(listBox);
                }
            }
        }
        //this function handles the saving and serialization of the information
        private void saveAs_menu_Click(object sender, RoutedEventArgs e)
        {
            if(stores.Count == 0)
            {
                invalidInput("Nothing To Be Saved!");
            }
            else
            {
                var saveFileDialog = new SaveFileDialog();

                saveFileDialog.Filter = "store files (*.sto)|*.sto";
                saveFileDialog.FilterIndex = 0;
                saveFileDialog.RestoreDirectory = true;

                saveFileDialog.DefaultExt = ".sto";
                if(saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    using (Stream stream = File.Open(saveFileDialog.FileName,FileMode.Create))
                    {
                        try
                        {
#pragma warning disable SYSLIB0011 // Type or member is obsolete
                            binaryFormatter.Serialize(stream, stores);
#pragma warning restore SYSLIB0011 // Type or member is obsolete
                        }
                        catch(SerializationException ex) 
                        { 
                            Console.WriteLine("Failure During Serialization! Cause: " + ex.Message);
                           
                        }
                    }
                }
            }
        }
        //this function handles the deserialization of a file
        private void open_menu_Click(object sender, RoutedEventArgs e)
        {
            
            System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog();

            openFileDialog.Filter = "store files (*.sto)|*.sto";
            if(openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                using (Stream stream = File.Open(openFileDialog.FileName, FileMode.Open))
                {
                    try
                    {
#pragma warning disable SYSLIB0011 // Type or member is obsolete
                        stores = (List<store>)binaryFormatter.Deserialize(stream);
#pragma warning restore SYSLIB0011 // Type or member is obsolete
                    }
                    catch(SerializationException ex)
                    {
                        Console.WriteLine("Failure During Deserialization! Cause: " + ex.Message);
                        
                    }
                }
            }
            showStoresOnList();
            clearAllFields();

        }
       
        private void clear_menu_Click(object sender, RoutedEventArgs e)
        {
            clearAllInfo();

        }
        //will clear out all store information present
        public void clearAllInfo()
        {
            stores.Clear();
            ItemListBox.Items.Clear();
            EmployeeListListBox.Items.Clear();
            StoreListListBox.Items.Clear();
            clearAllFields();

        }
        //just clears fields
        public void clearAllFields()
        {
            clearItemFields();
            clearEmployeeFields();
            EmployeeListListBox.Items.Clear();
            ItemListBox.Items.Clear();
            StoreNameTextBox.Clear();
            StoreAddressTextBox.Clear();
            StoreNumberTextBox.Clear();
        }
    }
}
