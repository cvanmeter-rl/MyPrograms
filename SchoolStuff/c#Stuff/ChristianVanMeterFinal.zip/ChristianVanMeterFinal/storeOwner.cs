﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristianVanMeterFinal
{
    [Serializable]
    class storeOwner:manager
    {
        //code that can overwrite things on register/etc
        private int overwriteCode = 000000;
        //constructor for store owner
        public storeOwner(string firstName, string lastName, string phoneNum, string gender, string position, double hourlyPay, double paycheckTotal, double hours,int storeSafeCode,int overwriteCode):base(firstName, lastName, phoneNum, gender, position, hourlyPay, paycheckTotal,hours,storeSafeCode)
        {
            this.overwriteCode = overwriteCode;
        }
        //properties for store owner
        public int OverwriteCode
        {
            get { return overwriteCode; }
            set { overwriteCode = value; }
        }
    }
}
