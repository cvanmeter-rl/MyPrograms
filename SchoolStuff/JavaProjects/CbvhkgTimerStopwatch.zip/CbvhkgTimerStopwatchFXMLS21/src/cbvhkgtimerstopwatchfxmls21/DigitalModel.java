/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgtimerstopwatchfxmls21;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
/**
 *
 * @author Christian VanMeter
 */
public class DigitalModel {
     private Timeline timeline;
    private KeyFrame keyFrame;
    
    private int milli = 1;
    private int second = 0;
    
    
    private String ddSecond = "";
    private String ddMinute = "";
    private String ddMillisecond = "";
    
    
    
    private int minutes = 0;
    private int seconds = 0;
    private int milliseconds = 0;
    private int hours = 0;
    
    private int prevMinutes = 0;
    private int prevSeconds = 0;
    private int prevMilliseconds = 0;
    private int prevHours = 0;
    
    private int recordMin = 0;
    private int recordSec = 0;
    private int recordMilli = 0;
    private int recordHours = 0;
    
    private int num = 0;
    
    private int totalMin = 0;
    private int totalSec = 0;
    private int totalHours = 0;
    private int totalMilli = 0;
    public void addAverageMin(int min){
        totalMin += min;
    }
    public void addAverageMilli(int milli){
        totalMilli += milli;
    }
    public void addAverageHours(int hour){
        totalHours += hour;
    }
    public void addAverageSec(int sec){
        totalSec += sec;
    }
    public int getAverageMin(){
        return (totalMin / num);
    }
    public int getAverageSec(){
        return (totalSec / num);
    }
    public int getAverageMilli(){
        return (totalMilli / num);
    }
    public int getAverageHours(){
        return (totalHours / num);
    }
    public void resetAverageValues(){
        totalMin = 0;
        totalSec = 0;
        totalHours = 0;
        totalMilli = 0;
    }
    public void resetPrevTime(){
        prevMinutes = 0;
        prevSeconds = 0;
        prevMilliseconds = 0;
        prevHours = 0;
    }
    void timeDif(){
        int s = seconds;
        int m = minutes;
        int mm = milliseconds;
        int h = hours;
        
        if(num == 0){
            recordMilli = milliseconds;
            recordMin = minutes;
            recordHours = hours;
            recordSec = seconds;
              
        }
        if(prevMilliseconds > mm){
            s--;
            mm += 100;
        }
        recordMilli = mm - prevMilliseconds;
        if(prevSeconds > s){
            m--;
            s += 60;
        }
        recordSec = s - prevSeconds;
        if(prevMinutes > m){
            h--;
            m += 60;
        }
        recordMin = m - prevMinutes;
        recordHours = h - prevHours;

        prevMilliseconds = recordMilli;
        prevSeconds = recordSec;
        prevMinutes = recordMin;
        prevHours = recordHours;
        num++;
    }
    public void setPrevMin(int num){
        prevMinutes = num;
    }
    public void setPrevSec(int num){
        prevSeconds = num;
    }
    public void setPrevMilli(int num){
        prevMilliseconds = num;
    }
    public void setPrevHours(int num){
        prevHours = num;
    }
    public void setLapCount(int lap){
        num = lap;
    }
    public int getRecordMin(){
        return recordMin;
    }
    public int getRecordSec(){
        return recordSec;
    }
    public int getRecordMilli(){
        return recordMilli;
    }
    public int getRecordHours(){
        return recordHours;
    }
    public int getLapCount(){
        return num;
    }
    public void incrementMilli(){
        milliseconds++;
    }
    public void incrementHours(){
        hours++;
    }
    public void incrementSeconds(){
        seconds++;
    }
    public void incrementMinutes(){
        minutes++;
    }
    public void setTimeMinutes(int min){
        minutes = min;
    }
    
    public void setMilliseconds(int milli){
        milliseconds = milli;
    }
    public int getTimeMilliseconds(){
        return milliseconds;
    }
    public void setSeconds(int sec){
        seconds = sec;
    }
    public void setHours(int hours){
        this.hours = hours;
    }
    public int getTimeMinutes(){
        return minutes;
    }
    public int getTimeSeconds(){
        return seconds;
    }
    public int getTimeHours(){
        return hours;
    }
    public void decrementMilli(){
        milli--;
    }
    public void setMilli(int milli){
        this.milli = milli;
    }
    public void setSec(int second){
        this.second = second;
    }
    public void decrementSec(){
        second -= 1;
    }
    public boolean checkTimer(){
        if(milli <= 0 && second == 0){
            return false;
        }
        return true;
    }
    public int getSeconds(){
        return second;
    }
    public int getMilli(){
        return milli;
    }
    
    public boolean isRunnning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
}
