/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgtimerstopwatchfxmls21;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.util.Duration;
/**
 *
 * @author Christian VanMeter
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private ImageView dialImageView;
    @FXML
    private ImageView handImageView;
    @FXML
    private Text time;
    @FXML
    private Text timer;
    @FXML
    private Text lap;
    @FXML
    private Text averageLap;
    @FXML
    private Button startStop;
    @FXML
    private Button recordReset;
    @FXML
    private CategoryAxis xAxis;
    @FXML
    private NumberAxis yAxis;
    @FXML
    private LineChart<?,?> lineChart;
    @FXML
    private CategoryAxis axisX;
    @FXML
    private NumberAxis axisY;
    @FXML
    private AreaChart<?,?> areaChart;
    
    AnalogModel analogModel;
    DigitalModel digitalModel;
    private XYChart.Series series2;
    private XYChart.Series series;
    private String ddSecond = "";
    private String ddMinute = "";
    private String ddMillisecond = "";
    private String ddHours = "";
    private int sec;
    
    private Timeline timelineDigital;
    private KeyFrame keyFrameDigital;
    
    TextInputDialog td = new TextInputDialog();

    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    
    private void digitalTimerSetup(){
        timer.setText("Timer: --:--");
        td.setTitle("Timer Start Time Set Up");
        td.setHeaderText("Set up the start time");
        td.setContentText("Please set up the start time (Integer):");
        Optional<String> result = td.showAndWait();
        boolean correctValue = false;
        result.ifPresent(name ->{
            timer.setText(name);
        });
        String input = timer.getText();
        while(correctValue == false){
            if(input.isEmpty()){
                result = td.showAndWait();
                result.ifPresent(name ->{
                    timer.setText(name);
                });
                input = timer.getText();
            }
            else if(checkForChar(input) == false){
                result = td.showAndWait();
                result.ifPresent(name ->{
                    timer.setText(name);
                });
                input = timer.getText();
            }
            else
            {
                correctValue = true;
            }
        }
        digitalTimer();
    }

    public void digitalTimer(){
        DecimalFormat dFormat = new DecimalFormat("00");
        sec = getNum(timer.getText());
        ddSecond = dFormat.format(sec);
        
        timer.setText(ddSecond + ".00");

        digitalModel.setSec(sec);
        
        keyFrameDigital = new KeyFrame(Duration.millis(10),(ActionEvent actionEvent) -> {
            digitalModel.decrementMilli();
            if(digitalModel.checkTimer() == false)
            {
                timer.setText("Time's Up!");              
            }
            else {
                int m = digitalModel.getMilli();
                if(m == 0)
                {
                    digitalModel.decrementSec();
                    digitalModel.setMilli(100);
                }
                
                ddSecond = dFormat.format(digitalModel.getSeconds());
                ddMillisecond = dFormat.format(digitalModel.getMilli());
                
                timer.setText("Timer: " + ddSecond + "." + ddMillisecond);
            }
            
            digitalModel.incrementMilli();
            if(digitalModel.getTimeMilliseconds() % 100 == 0){
                digitalModel.incrementSeconds();
                digitalModel.setMilliseconds(0);
            }
            if(digitalModel.getTimeSeconds() == 60){
                digitalModel.setSeconds(0);
                digitalModel.incrementMinutes();
            }
            if(digitalModel.getTimeMinutes() == 60){
                digitalModel.setTimeMinutes(0);
                digitalModel.incrementHours();
            }
            ddSecond = dFormat.format(digitalModel.getTimeSeconds());
            ddMinute = dFormat.format(digitalModel.getTimeMinutes());
            ddMillisecond = dFormat.format(digitalModel.getTimeMilliseconds());
            ddHours = dFormat.format(digitalModel.getTimeHours());
            time.setText(ddHours + ":" + ddMinute + ":" + ddSecond + "." + ddMillisecond);            
        });
        
        timelineDigital = new Timeline(keyFrameDigital);
        timelineDigital.setCycleCount(Animation.INDEFINITE);
    }
    
    @FXML
    private void startStopMonitor(ActionEvent event){
        if ( !(analogModel.isRunnning())) {
            analogModel.start();
            timelineDigital.play();
            startStop.setText("Stop");
            recordReset.setText("Record");
        } else {
            analogModel.stop();
            timelineDigital.pause();
            startStop.setText("Start");
            recordReset.setText("Reset");
        }
    }
    @FXML
    private void recordResetMonitor(ActionEvent event){
        if(recordReset.getText().equalsIgnoreCase("Reset")){
            recordReset.setText("Record");
            reset();
        }
        else{
            if(digitalModel.checkTimer() == false){
                alert.setContentText("Time is up..No more records..");
                alert.show();
            }
            else{
                record();
                double total = (digitalModel.getRecordHours() * 3600.0) + (digitalModel.getRecordMin() * 60.0) + digitalModel.getRecordSec() + (digitalModel.getRecordMilli() / 60.0);
                if(total >= yAxis.getUpperBound()){
                    yAxis.setUpperBound((int)total + 5);
                }
                series.getData().add(new XYChart.Data(Integer.toString(digitalModel.getLapCount()), total));
            }
        
        }
    }
    private void reset(){
        time.setText("--:--:--.--");
        digitalModel.setSeconds(0);
        digitalModel.setMilliseconds(0);
        digitalModel.setTimeMinutes(0);
        digitalModel.setHours(0);
        
        timer.setText("Timer: --:--");
        digitalModel.setSec(sec);
        digitalModel.setMilli(1);
        
        lap.setText("Lap -: --:--:--.--");
        digitalModel.setLapCount(0);
        digitalModel.resetPrevTime();
        
        averageLap.setText("Average Lap Time: --:--:--.--");
        
        analogModel.resetSeconds();
        
        averageLap.setText("Average Lap Time: --:--:--.--");
        digitalModel.resetAverageValues();
        
        series.getData().clear();
        series2.getData().clear();
        yAxis.setUpperBound(5);
        axisY.setUpperBound(5);
    }
    private void record(){
       DecimalFormat dFormat = new DecimalFormat("00");
       digitalModel.timeDif();
       ddSecond = dFormat.format(digitalModel.getRecordSec());
       ddMinute = dFormat.format(digitalModel.getRecordMin());
       ddMillisecond = dFormat.format(digitalModel.getRecordMilli());
       ddHours = dFormat.format(digitalModel.getRecordHours());
       lap.setText("lap " + digitalModel.getLapCount() + ":" + ddHours + ":" + ddMinute + ":" + ddSecond + "." + ddMillisecond);
    
       digitalModel.addAverageHours(digitalModel.getRecordHours());
       digitalModel.addAverageMin(digitalModel.getRecordMin());
       digitalModel.addAverageSec(digitalModel.getRecordSec());
       digitalModel.addAverageMilli(digitalModel.getRecordMilli());
            
       ddSecond = dFormat.format(digitalModel.getAverageSec());
       ddMinute = dFormat.format(digitalModel.getAverageMin());
       ddMillisecond = dFormat.format(digitalModel.getAverageMilli());
       ddHours = dFormat.format(digitalModel.getAverageHours());
            
       averageLap.setText("Average Lap Time: " + ddHours + ":" + ddMinute + ":" + ddSecond + "." + ddMillisecond);
       double sum = (digitalModel.getAverageHours() * 3600.0) + (digitalModel.getAverageMin() * 60) + digitalModel.getAverageSec() + (digitalModel.getAverageMilli() / 60.0);
       if(sum >= axisY.getUpperBound()){
                   axisY.setUpperBound((int)sum + 5);
       }
       series2.getData().add(new XYChart.Data(Integer.toString(digitalModel.getLapCount()),(sum)));
    }
    private boolean checkForChar(String s){
        //reference from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
        for(int i = 0;i < s.length();i++){
            if(Character.isLetter(s.charAt(i)) || !Character.isDigit(s.charAt(i))){
                return false;
            } 
        }
        return true;
        //end of code referenced from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
    }
    private void updateAnalog(){
        handImageView.setRotate(analogModel.calculateRotation());
    }
    public void start(){
        analogModel.start();
    }
    
    public int getNum(String s){
        //referenced from https://mkyong.com/java/java-convert-string-to-int/
        int i = Integer.parseInt(s);
        //end of reference from https://mkyong.com/java/java-convert-string-to-int/
        return i;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        analogModel = new AnalogModel();
        digitalModel = new DigitalModel();
        
        analogModel.setupTimer(new KeyFrame(Duration.millis(analogModel.getTickTimeInSeconds() * 1000), (ActionEvent event) -> {
            updateAnalog();
        }));
        
        digitalTimerSetup();
        
        alert.setTitle("Time is up!");
        alert.setHeaderText("Alert");
       
        series2 = new AreaChart.Series();
        areaChart.getData().add(series2);
        series = new XYChart.Series();
        lineChart.getData().add(series);
        
        axisY.setAutoRanging(false);
        axisY.setLowerBound(0);
        axisY.setUpperBound(5);
        areaChart.setAnimated(false);
            
        yAxis.setAutoRanging(false);
        yAxis.setLowerBound(0);
        yAxis.setUpperBound(5);
        lineChart.setAnimated(false);
    }    
    
}
