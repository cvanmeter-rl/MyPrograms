/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgtimerstopwatchfxmls21;
import java.text.DecimalFormat;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.util.Duration;
/**
 *
 * @author Christian VanMeter
 */
public class AnalogModel {
    private double tickTimeInSeconds = 0.01;
    private double angleDeltaPerSeconds = 6.0;
    
    private double secondsElapsed = 0.0;
    
    private Timeline timeline;
    private KeyFrame keyFrame;
    
    
    
    public void setupTimer(KeyFrame keyFrame) {
        this.keyFrame = keyFrame;
        timeline = new Timeline(keyFrame);
        timeline.setCycleCount(Animation.INDEFINITE);
    }
    
    public double calculateRotation(){
        secondsElapsed += tickTimeInSeconds;
        return secondsElapsed * angleDeltaPerSeconds;
    }
    public void resetSeconds(){
        secondsElapsed = 0.0;
    }
    
    public void start() {
        timeline.play();
    }
    public void stop(){
        timeline.pause();
    }
    
    public void setTickTimeInSeconds(Double tickTimeInSeconds) {
        this.tickTimeInSeconds = tickTimeInSeconds;
        setupTimer(keyFrame);
    }
    
    public double getTickTimeInSeconds(){
        return tickTimeInSeconds;
    }
    public boolean isRunnning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
}
