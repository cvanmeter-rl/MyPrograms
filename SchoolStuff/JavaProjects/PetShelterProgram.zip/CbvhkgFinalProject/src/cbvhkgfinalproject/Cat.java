/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.io.Serializable;

/**
 *
 * @author Christian VanMeter
 */
public class Cat extends Pet implements CatInterface,Serializable{
    private String declawed;
    private String litterTrained;
    
    
    public Cat(String species,String name,String gender,int age,String breed,String spayNeuter,int weight,double adoptionCost,String declawed,String litterTrained){
        super("Cat",name,gender,age,breed,spayNeuter,weight,adoptionCost);
        this.declawed = declawed;
        this.litterTrained = litterTrained;
        
    }
    
    @Override
    public String isDeclawed()
    {
        return this.declawed;
    }
    public void setDeclawed(String declawed)
    {
        this.declawed = declawed;
    }
    
    @Override
    public String isLitterTrained()
    {
        return this.litterTrained;
    }
    public void setLitterTrained(String litterTrained)
    {
        this.litterTrained = litterTrained;
    }
}
