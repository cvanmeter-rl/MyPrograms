/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Christian VanMeter
 */
public class Model {
    public static ArrayList<Pet> petList = new ArrayList<Pet>();
    public static int numAnimals = -1;
    
    public Model()
    {
        
    }
    public void clearList()
    {
        for(int i = 0;i < petList.size();i++)
        {
            petList.remove(i);
        }
    }
    public void loadPets(ArrayList<Pet> pet)
    {
        for(int i = 0;i < pet.size();i++)
        {
            petList.add(i, pet.get(i));
        }
    }
    public Pet getPet(String name)
    {
        for(int i = 0;i < numAnimals+1;i++)
        {
            Pet p = petList.get(i);
            if(p.getName().equalsIgnoreCase(name))
            {
                return p;
            }
        }
        return null;
    }
    public int getIndex(String name)
    {
        for(int i = 0;i < numAnimals+1;i++)
        {
            Pet p = petList.get(i);
            if(p.getName().equalsIgnoreCase(name))
            {
                return i;
            }
        }
        return -1;
    }
    public int remove(String name)//0 means success, 1 means failure
    {
        for(int i = 0;i < numAnimals+1;i++)
        {
            Pet p = petList.get(i);
            if(p.getName().equalsIgnoreCase(name))
            {
                petList.remove(i);
                numAnimals--;
                return 0;
            }
        }
        return 1;
    }
    public void addDog(Dog d)
    {
        petList.add(d);
        numAnimals++;
        
       // System.out.println(petList.get(numAnimals).getName());
        
    }
    public void addCat(Cat c)
    {
        
        petList.add(c);
        numAnimals++;
        
        //System.out.println(petList.get(numAnimals).getName());
    }
   
    public String print(int index)
    {
        String species = petList.get(index).getSpecies();
        String info;
        if(species.equalsIgnoreCase("Dog"))
        {
            Dog d = (Dog)petList.get(index);
            info ="Pet #" + (index+1) + ",Species:" + d.getSpecies() +",Name:"+d.getName()
            +",Gender:"+d.getGender()+",Age:"+d.getAge()+",Breed:"+d.getBreed()+",Spayed/Neutered:"+d.getSpayNeuter()+
             "\nWeight:"+d.getWeight()+",Adoption Cost:"+d.getAdoptionCost()+",House Trained:"+d.isHouseTrained()+
             ",Crate Trained:"+d.isCrateTrained()+".\n****************************************************************************************\n";
            return info;
        }
        else
        {
            Cat c = (Cat)petList.get(index);
            info ="Pet #" + (index+1) + ",Species:" + c.getSpecies() +",Name:"+c.getName()
            +",Gender:"+c.getGender()+",Age:"+c.getAge()+",Breed:"+c.getBreed()+",Spayed/Neutered:"+c.getSpayNeuter()+
             "\nWeight:"+c.getWeight()+",Adoption Cost:"+c.getAdoptionCost()+",Declawed:"+c.isDeclawed()+
             ",Litter Trained:"+c.isLitterTrained()+".\n****************************************************************************************\n";
            return info;
        }
    }
}
