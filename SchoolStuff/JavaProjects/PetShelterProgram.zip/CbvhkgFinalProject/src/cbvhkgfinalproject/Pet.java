/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.io.Serializable;

/**
 *
 * @author Christian VanMeter
 */
public class Pet implements Serializable{
    private String species;
    private String name;
    private String gender;
    private int age;
    private String breed;
    private String spayNeuter;
    private int weight;
    private double adoptionCost;
    
    
    
    public Pet(String species,String name,String gender,int age,String breed,String spayNeuter,int weight,double adoptionCost){
        this.species = species;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.breed = breed;
        this.spayNeuter = spayNeuter;
        this.weight = weight;
        this.adoptionCost = adoptionCost;
        
    }
    
    public String getSpecies()
    {
        return this.species;
    }
    public void setSpecies(String species)
    {
        this.species = species;
    }
    
    public String getName()
    {
        return this.name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getGender()
    {
        return this.gender;
    }
    public void setGender(String gender)
    {
        this.gender = gender;
    }
    
    public int getAge(){
        return this.age;
    }
    public void setAge(int age)
    {
        this.age = age;
    }
    
    public String getBreed()
    {
        return this.breed;
    }
    public void setBreed(String breed)
    {
        this.breed = breed;
    }
    
    public String getSpayNeuter()
    {
        return this.spayNeuter;
    }
    public void setSpayNeuter(String spayNeuter)
    {
        this.spayNeuter = spayNeuter;
    }
    
    public int getWeight()
    {
        return this.weight;
    }
    public void setWeight(int weight)
    {
        this.weight = weight;
    }
    
    public double getAdoptionCost()
    {
        return this.adoptionCost;
    }
    public void setAdoptionCost(double adoptionCost)
    {
        this.adoptionCost = adoptionCost;
    }
    
}
