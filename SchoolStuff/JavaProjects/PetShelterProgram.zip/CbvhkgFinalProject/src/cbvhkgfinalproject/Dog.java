/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.io.Serializable;

/**
 *
 * @author Christian VanMeter
 */
public class Dog extends Pet implements DogInterface,Serializable{
    private String houseTrained;
    private String crateTrained;
    

    public Dog(String species,String name,String gender,int age,String breed,String spayNeuter,int weight,double adoptionCost,String houseTrained,String crateTrained){
        super("Dog",name,gender,age,breed,spayNeuter,weight,adoptionCost);
        this.houseTrained = houseTrained;
        this.crateTrained = crateTrained;
        
    }
    
    @Override
    public String isHouseTrained()
    {
        return this.houseTrained;
    }
    @Override
    public String isCrateTrained()
    {
        return this.crateTrained;
    }
    
    public void setHouseTrained(String houseTrained){
        this.houseTrained = houseTrained;
    }
    public void setCrateTrained(String crateTrained)
    {
        this.crateTrained = crateTrained;
    }
}
