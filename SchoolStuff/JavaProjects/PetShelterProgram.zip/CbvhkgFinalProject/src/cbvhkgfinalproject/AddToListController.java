/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
/**
 *
 * @author Christian VanMeter
 */
public class AddToListController extends Switchable implements Initializable{
    
    @FXML
    private ComboBox speciesComboBox;
    @FXML
    private TextField petName;
    @FXML
    private ComboBox genderComboBox;
    @FXML
    private TextField petAge;
    @FXML
    private TextField petBreed;
    @FXML
    private ComboBox spayNeuterComboBox;
    @FXML
    private TextField petWeight;
    @FXML
    private TextField adoptionCost;
    @FXML
    private ComboBox declawCatComboBox;
    @FXML
    private ComboBox litterTrainedComboBox;
    @FXML
    private ComboBox houseTrainedComboBox;
    @FXML
    private ComboBox crateTrainedComboBox;
    
    Model model;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO        
        declawCatComboBox.getItems().add("Yes");
        declawCatComboBox.getItems().add("No");
        
        litterTrainedComboBox.getItems().add("Yes");
        litterTrainedComboBox.getItems().add("No");
        
        houseTrainedComboBox.getItems().add("Yes");
        houseTrainedComboBox.getItems().add("No");
        
        crateTrainedComboBox.getItems().add("Yes");
        crateTrainedComboBox.getItems().add("No");
        
        speciesComboBox.getItems().add("Dog");
        speciesComboBox.getItems().add("Cat");
        
        genderComboBox.getItems().add("Male");
        genderComboBox.getItems().add("Female");
        
        spayNeuterComboBox.getItems().add("Yes");
        spayNeuterComboBox.getItems().add("No");
        
        model = new Model();
        

    }
     
    @FXML
    private void addPetToList()
    {
        double cost = 0.0;
        int weight = 0;
        int age = 0;
        
        if(speciesComboBox.getSelectionModel().isEmpty() || petName.getText().isEmpty() || genderComboBox.getSelectionModel().isEmpty()
           || petAge.getText().isEmpty() || petBreed.getText().isEmpty() || spayNeuterComboBox.getSelectionModel().isEmpty()
           || petWeight.getText().isEmpty() || adoptionCost.getText().isEmpty())      
        {
            displayErrorAlert("Not all Information was entered. Please fill in and select an option for each field.");
        }
        else{
            if(speciesComboBox.getValue().toString().equalsIgnoreCase("dog"))
            {
                if(houseTrainedComboBox.getSelectionModel().isEmpty() || crateTrainedComboBox.getSelectionModel().isEmpty())
                {
                    displayErrorAlert("Information Pertaining to Only Dogs Wasn't Filled Out Completely");               
                }
                else
                {
                    if(checkForChar(petAge.getText()) == false)
                    {
                        displayErrorAlert("The Pet Age Must Not Contain Characters");
                    }
                    else if(checkForChar(petWeight.getText()) == false)
                    {
                        displayErrorAlert("The Pet Weight Must Not Contain Characters");
                    }
                    else if(checkForChar(adoptionCost.getText()) == false)
                    {
                        displayErrorAlert("Adoption Cost Must Not Contain Characters");
                    }
                    else
                    {
                        age = Integer.parseInt(petAge.getText());
                        weight = Integer.parseInt(petWeight.getText());
                        cost = Double.parseDouble(adoptionCost.getText());
                        
                        Dog d = new Dog(speciesComboBox.getValue().toString(),petName.getText(),genderComboBox.getValue().toString(),age,petBreed.getText(),spayNeuterComboBox.getValue().toString(),weight,cost,houseTrainedComboBox.getValue().toString(),
                    crateTrainedComboBox.getValue().toString());
                    
                    model.addDog(d);
                    resetInfo();
                    displayPetAddedAlert("Dog Successfully Added To List");
                    
                    }
                    
                }
            }
            else
            {
                if(declawCatComboBox.getSelectionModel().isEmpty() || litterTrainedComboBox.getSelectionModel().isEmpty())
                {
                    displayErrorAlert("Information Pertaining to Only Cats Wasn't Filled Out Completely");
                }
                else
                {
                  if(checkForChar(petAge.getText()) == false)
                    {
                        displayErrorAlert("The Pet Age Must Not Contain Characters");
                    }
                    else if(checkForChar(petWeight.getText()) == false)
                    {
                        displayErrorAlert("The Pet Weight Must Not Contain Characters");
                    }
                    else if(checkForChar(adoptionCost.getText()) == false)
                    {
                        displayErrorAlert("Adoption Cost Must Not Contain Characters");
                    }
                    else
                    {
                    Cat c = new Cat(speciesComboBox.getValue().toString(),petName.getText(),genderComboBox.getValue().toString(),age,petBreed.getText(),spayNeuterComboBox.getValue().toString(),weight,cost,declawCatComboBox.getValue().toString(),
                    litterTrainedComboBox.getValue().toString());
                    
                    model.addCat(c);
                    resetInfo();
                    displayPetAddedAlert("Cat Successfully Added To List");
                    
                    }
                 }
                }
            }
        }
    boolean checkForChar(String s){
        //reference from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
        for(int i = 0;i < s.length();i++){
            if(Character.isLetter(s.charAt(i))){
                return false;
            } 
        }
        return true;
        //end of code referenced from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
    }
    private void displayPetAddedAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Pet Successfully Added");
        //alert.setHeaderText("Error!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void displayErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        //alert.setHeaderText("Error!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private void goToHome(ActionEvent event){
        resetInfo();
        Switchable.switchTo("HomeScreen");
    }
    
    //@FXML
    //private void goToEditList(ActionEvent event){
    //    resetInfo();
    //    Switchable.switchTo("EditList");
    //}
    private void resetInfo()
    {
        declawCatComboBox.valueProperty().set(null);
        litterTrainedComboBox.valueProperty().set(null);
        houseTrainedComboBox.valueProperty().set(null);
        crateTrainedComboBox.valueProperty().set(null);
        speciesComboBox.valueProperty().set(null);
        genderComboBox.valueProperty().set(null);
        spayNeuterComboBox.valueProperty().set(null);
        
        petName.clear();
        petAge.clear();
        petBreed.clear();
        petWeight.clear();
        adoptionCost.clear();
    }
}
