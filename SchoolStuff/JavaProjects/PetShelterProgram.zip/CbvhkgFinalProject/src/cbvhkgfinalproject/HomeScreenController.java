/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkgfinalproject;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author Christian VanMeter
 */
public class HomeScreenController extends Switchable implements Initializable{
    Model model;
    @FXML TextArea listOfPets;
    @FXML TextField petName;
    @FXML TextField petAge;
    @FXML TextField petBreed;
    @FXML TextField petWeight;
    @FXML TextField adoptionCost;
    
    
    @FXML ComboBox gender;
    @FXML ComboBox spayNeuter;
    @FXML ComboBox declawHouse;
    @FXML ComboBox litterCrate;
    
    
    @FXML Label genderLabel;
    @FXML Label ageLabel;
    @FXML Label breedLabel;
    @FXML Label spayNeuterLabel;
    @FXML Label weightLabel;
    @FXML Label adoptionLabel;
    @FXML Label declawHouseLabel;
    @FXML Label litterCrateLabel;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    model = new Model();
    
    
    genderLabel.setVisible(false);
    ageLabel.setVisible(false);
    breedLabel.setVisible(false);
    spayNeuterLabel.setVisible(false);
    weightLabel.setVisible(false);
    adoptionLabel.setVisible(false);
    declawHouseLabel.setVisible(false);
    litterCrateLabel.setVisible(false);
    
    petAge.setVisible(false);
    petBreed.setVisible(false);
    petWeight.setVisible(false);
    adoptionCost.setVisible(false);
    
    
    gender.setVisible(false);
    spayNeuter.setVisible(false);
    declawHouse.setVisible(false);
    litterCrate.setVisible(false);
    
    gender.getItems().add("Male");
            gender.getItems().add("Female");
            
            spayNeuter.getItems().add("Yes");
            spayNeuter.getItems().add("No");
            
            declawHouse.getItems().add("Yes");
            declawHouse.getItems().add("No");
            
            litterCrate.getItems().add("Yes");
            litterCrate.getItems().add("No");
    }
    
    @FXML
    public void handleSave(ActionEvent event)
    {
        try{
        FileOutputStream writeData = new FileOutputStream("PetList");
        ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
        
        writeStream.writeObject(Model.petList);
        writeStream.flush();
        writeStream.close();
        displayInfoAlert("File Saved to Class File Directory Under The Name PetList");
        
        
        }catch (IOException e) {
        displayErrorAlert("Error occured when saving file");
        }
           
    }
    @FXML
    public void handleOpen(ActionEvent event)
    {
        try{
            FileInputStream readData = new FileInputStream("PetList");
            ObjectInputStream readStream = new ObjectInputStream(readData);

            ArrayList<Pet> list = (ArrayList<Pet>) readStream.readObject();
            readStream.close();
            model.clearList();
            String p;
            for(int i = 0;i < list.size();i++)
            {
                p = list.get(i).getSpecies();
                if(p.equalsIgnoreCase("dog"))
                {
                    model.addDog((Dog)list.get(i));
                }
                else
                {
                    model.addCat((Cat)list.get(i));
                }
                //Model.petList.add(list.get(i));
                //listOfPets.appendText(model.print(i));
            }
            updateText();
            System.out.println(list.size());
            System.out.println(Model.petList.size());
        }catch (Exception e) {
           displayErrorAlert("Error occured when loading file");
        }
        
    }
    
    private void displayInfoAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Info");
        //alert.setHeaderText("Error!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public void removePet(ActionEvent event)
    {
        String remove = petName.getText();
        int result = model.remove(remove);
        if(result == 0)
        {
        updateText();
        displayInfoAlert("Pet Successfully Removed From List");
        }
        else
        {
        displayInfoAlert("No Pet with that Name was Found");
        }
    }
    @FXML
    public void loadData(ActionEvent event)
    {
        String load = petName.getText();
        Pet p = model.getPet(load);
        if(p == null)
        {
            displayErrorAlert("No Pet Was Found in the List with That Name");
        }
        else
        {
            
            genderLabel.setVisible(true);
            ageLabel.setVisible(true);
            breedLabel.setVisible(true);
            spayNeuterLabel.setVisible(true);
            weightLabel.setVisible(true);
            adoptionLabel.setVisible(true);
            declawHouseLabel.setVisible(true);
            litterCrateLabel.setVisible(true);
    
            petAge.setVisible(true);
            petBreed.setVisible(true);
            petWeight.setVisible(true);
            adoptionCost.setVisible(true);
    
            
            gender.setVisible(true);
            spayNeuter.setVisible(true);
            declawHouse.setVisible(true);
            litterCrate.setVisible(true);
            
            
            if(p.getSpecies().equalsIgnoreCase("dog"))
            {
                declawHouseLabel.setText("Is Dog House Trained:");
                litterCrateLabel.setText("Is Dog Crate Trained:");
                
                Dog d = (Dog)p;
                
                gender.setValue(d.getGender());
                spayNeuter.setValue(d.getSpayNeuter());
                declawHouse.setValue(d.isHouseTrained());
                litterCrate.setValue(d.isCrateTrained());
                petAge.setText(String.valueOf(d.getAge()));
                petBreed.setText(d.getBreed());
                petWeight.setText(String.valueOf(d.getWeight()));
                adoptionCost.setText(String.valueOf(d.getAdoptionCost()));
                
                
            }
            else
            {
                declawHouseLabel.setText("Is Cat Declawed:");
                litterCrateLabel.setText("Is Cat Litter Trained:");
                Cat c = (Cat)p;
                
                gender.setValue(c.getGender());
                spayNeuter.setValue(c.getSpayNeuter());
                declawHouse.setValue(c.isDeclawed());
                litterCrate.setValue(c.isLitterTrained());
                petAge.setText(String.valueOf(c.getAge()));
                petBreed.setText(c.getBreed());
                petWeight.setText(String.valueOf(c.getWeight()));
                adoptionCost.setText(String.valueOf(c.getAdoptionCost()));
                
            }
        }
    }
    @FXML
    public void confirmEdit(ActionEvent event)
    {
        String load = petName.getText();
        Pet p = model.getPet(load);
        int index = model.getIndex(load);
        
        double cost = 0.0;
        int weight = 0;
        int age = 0;
        if(index == -1)
        {
            displayErrorAlert("Pet was not found in list");
        }
        else
        {
            if(p.getSpecies().equalsIgnoreCase("dog"))
            {
                Dog d = (Dog)p;
                if(!gender.getValue().toString().equalsIgnoreCase(d.getGender()))
                {
                    Model.petList.get(index).setGender(gender.getValue().toString());
                }
                if(!petAge.getText().equalsIgnoreCase(String.valueOf(d.getAge())))
                {
                    if(checkForChar(petAge.getText()) == false)
                    {
                        displayErrorAlert("The Pet Age Must Not Contain Characters");
                    }
                    else
                    {
                        age = Integer.parseInt(petAge.getText());
                        Model.petList.get(index).setAge(age);
                    }
                }
                if(!petWeight.getText().equalsIgnoreCase(String.valueOf(d.getWeight())))
                {
                    if(checkForChar(petWeight.getText()) == false)
                    {
                        displayErrorAlert("The Pet Weight Must Not Contain Characters");
                    }
                    else
                    {
                        weight = Integer.parseInt(petWeight.getText());
                        Model.petList.get(index).setWeight(weight);
                    }
                }
                if(!petBreed.getText().equalsIgnoreCase(d.getBreed()))
                {
                    Model.petList.get(index).setBreed(petBreed.getText());
                }
                if(!spayNeuter.getValue().toString().equalsIgnoreCase(d.getSpayNeuter()))
                {
                    Model.petList.get(index).setSpayNeuter(spayNeuter.getValue().toString());
                }
                if(!adoptionCost.getText().equalsIgnoreCase(String.valueOf(d.getAdoptionCost())))
                {
                    if(checkForChar(adoptionCost.getText()) == false)
                    {
                        displayErrorAlert("The Pet Adoption Cost Must Not Contain Characters");
                    }
                    else
                    {
                        cost = Double.parseDouble(adoptionCost.getText());
                        Model.petList.get(index).setAdoptionCost(cost);
                    }
                }
                if(!declawHouse.getValue().toString().equalsIgnoreCase(d.isHouseTrained()))
                {
                    d = (Dog) Model.petList.get(index);
                    d.setHouseTrained(declawHouse.getValue().toString());
                    Model.petList.remove(index);
                    Model.petList.add(index, d);
                }
                if(!litterCrate.getValue().toString().equalsIgnoreCase(d.isCrateTrained()))
                {
                    d = (Dog) Model.petList.get(index);
                    d.setCrateTrained(declawHouse.getValue().toString());
                    Model.petList.remove(index);
                    Model.petList.add(index, d);
                }
                
                updateText();
            }
            else
            {
                Cat c = (Cat)p;
                
                if(!gender.getValue().toString().equalsIgnoreCase(c.getGender()))
                {
                    Model.petList.get(index).setGender(gender.getValue().toString());
                }
                if(!petAge.getText().equalsIgnoreCase(String.valueOf(c.getAge())))
                {
                    if(checkForChar(petAge.getText()) == false)
                    {
                        displayErrorAlert("The Pet Age Must Not Contain Characters");
                    }
                    else
                    {
                        age = Integer.parseInt(petAge.getText());
                        Model.petList.get(index).setAge(age);
                    }
                }
                if(!petWeight.getText().equalsIgnoreCase(String.valueOf(c.getWeight())))
                {
                    if(checkForChar(petWeight.getText()) == false)
                    {
                        displayErrorAlert("The Pet Weight Must Not Contain Characters");
                    }
                    else
                    {
                        weight = Integer.parseInt(petWeight.getText());
                        Model.petList.get(index).setWeight(weight);
                    }
                }
                if(!petBreed.getText().equalsIgnoreCase(c.getBreed()))
                {
                    Model.petList.get(index).setBreed(petBreed.getText());
                }
                if(!spayNeuter.getValue().toString().equalsIgnoreCase(c.getSpayNeuter()))
                {
                    Model.petList.get(index).setSpayNeuter(spayNeuter.getValue().toString());
                }
                if(!adoptionCost.getText().equalsIgnoreCase(String.valueOf(c.getAdoptionCost())))
                {
                    if(checkForChar(adoptionCost.getText()) == false)
                    {
                        displayErrorAlert("The Pet Adoption Cost Must Not Contain Characters");
                    }
                    else
                    {
                        cost = Double.parseDouble(adoptionCost.getText());
                        Model.petList.get(index).setAdoptionCost(cost);
                    }
                }
                if(!declawHouse.getValue().toString().equalsIgnoreCase(c.isDeclawed()))
                {
                    c = (Cat) Model.petList.get(index);
                    c.setDeclawed(declawHouse.getValue().toString());
                    Model.petList.remove(index);
                    Model.petList.add(index, c);
                }
                if(!litterCrate.getValue().toString().equalsIgnoreCase(c.isLitterTrained()))
                {
                    c = (Cat) Model.petList.get(index);
                    c.setLitterTrained(declawHouse.getValue().toString());
                    Model.petList.remove(index);
                    Model.petList.add(index, c);
                }
                
                updateText();
            }
        }
    }
    boolean checkForChar(String s){
        //reference from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
        for(int i = 0;i < s.length();i++){
            if(Character.isLetter(s.charAt(i))){
                return false;
            } 
        }
        return true;
        //end of code referenced from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
    }
    private void displayErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        //alert.setHeaderText("Error!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public void updateText()
    {
        listOfPets.clear();
        //int index = Model.numAnimals;
        //System.out.println(index);
        
        for(int i = 0;i < Model.numAnimals+1;i++)
        {
            listOfPets.appendText(model.print(i));
            //index--;
        }
    }
    
    @FXML
    public void handleAbout(ActionEvent event){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("About This Application");
        alert.setContentText("This application was developed by Christian VanMeter for CS330 at Mizzou. This application emulates a pet directory that a local shelter could use to keep track of animals at the shelter.");
        alert.showAndWait();
    }
    
    @FXML
    private void goToAddList(ActionEvent event){
        Switchable.switchTo("AddToList");
    }
    //@FXML
    //private void goToEditList(ActionEvent event){
    //    Switchable.switchTo("EditList");
    //}
}
