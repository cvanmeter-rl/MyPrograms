/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cbvhkggpacalculatorf21;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Christian VanMeter
 */
public class CbvhkgGPACalculatorF21 extends Application {
    private int width = 500;
    private int height = 425;
    private String title = "GPA Calculator";
    private int textWidth = 350;
    
    private String fontStyle = "Comic Sans MS";
    @Override
    public void start(Stage primaryStage) {
        
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error Found");
        alert.setHeaderText("Error with Info");
        
        Alert alert2 = new Alert(AlertType.INFORMATION);
        alert.setTitle("Info");
        alert.setHeaderText("Alert Button Pressed");
        
        GridPane root = new GridPane();
        root.setAlignment(Pos.BASELINE_CENTER);
        root.setVgap(10);
        root.setHgap(10);
        root.setPadding(new Insets(15,15,15,15));
        
        Label course1 = new Label("Course 1: ");
        course1.setFont(Font.font(fontStyle,FontWeight.NORMAL,18));
        root.add(course1,0,0,1,1);
        
        TextField score1 = new TextField();
        score1.setPrefWidth(350);
        root.add(score1,1,0,1,1);
        
        Label course2 = new Label("Course 2: ");
        course1.setFont(Font.font(fontStyle,FontWeight.NORMAL,18));
        root.add(course2,0,1,1,1);
        
        TextField score2 = new TextField();
        score2.setPrefWidth(350);
        root.add(score2,1,1,1,1);
        
        Label course3 = new Label("Course 3: ");
        course1.setFont(Font.font(fontStyle,FontWeight.NORMAL,18));
        root.add(course3,0,2,1,1);
        
        TextField score3 = new TextField();
        score3.setPrefWidth(350);
        root.add(score3,1,2,1,1);
        
        Label course4 = new Label("Course 4: ");
        course1.setFont(Font.font(fontStyle,FontWeight.NORMAL,18));
        root.add(course4,0,3,1,1);
        
        TextField score4 = new TextField();
        score4.setPrefWidth(350);
        root.add(score4,1,3,1,1);
        
        Label information = new Label("Information: ");
        information.setFont(Font.font(fontStyle,FontWeight.NORMAL,18));
        root.add(information,0,4,2,1);
        
        TextArea infoArea = new TextArea();
        infoArea.setPrefRowCount(3);
        infoArea.setWrapText(true);
        infoArea.setEditable(false);
        root.add(infoArea,0,5,2,1);
        
        Button buttonGPA = new Button("Calculate GPA Score");
        buttonGPA.setMaxWidth(Double.MAX_VALUE);
        
       
        
        buttonGPA.setOnAction((new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent e){
                String class1;
                class1 = score1.getText();
                String class2;
                class2 = score2.getText();
                String class3;
                class3 = score3.getText();
                String class4;
                class4 = score4.getText();
                System.out.println("GPA button clicked");
                 double averageScore;
                 if(class1.isEmpty() || class2.isEmpty() || class3.isEmpty() || class4.isEmpty()){
                     System.out.println("Error:Please fill in all scores for all 4 Classes");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error:Please fill in all scores for all 4 Classes");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                 }
                 else if(checkForChar(class1) == false || checkForChar(class2) == false || checkForChar(class3) == false || checkForChar(class4) == false)
                 {
                     System.out.println("Error: A Character has been entered in as a score!");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error: A Character has been entered in as a score!");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                 }
                 else if(getNum(class1) < 0 || getNum(class1) > 100 || getNum(class2) < 0 || getNum(class2) > 100 || getNum(class3) < 0 || getNum(class3) > 100 || getNum(class4) < 0 || getNum(class4) > 100){
                     System.out.println("Error: A score was entered that is outside of the range of 0 to 100");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error: A score was entered that is outside of the range of 0 to 100");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                 }
                 else{
                     averageScore = (((double)getNum(class1)+getNum(class2)+getNum(class3)+getNum(class4))/4.0);
                     infoArea.appendText("Your average score is: " + class1 + " + " + class2 + " + " + class3 + " + " + class4 + " / 4 = " + averageScore + "\n");
                     if(averageScore <= 100 && averageScore >= 87)
                     {
                         infoArea.appendText("Your GPA is: A\n");
                     }
                     else if(averageScore < 87 && averageScore >= 77)
                     {
                         infoArea.appendText("Your GPA is: B\n");
                     }
                     else if(averageScore < 77 && averageScore >= 67)
                     {
                         infoArea.appendText("Your GPA is: C\n");
                     }
                     else if(averageScore < 67 && averageScore >= 60)
                     {
                         infoArea.appendText("Your GPA is: D\n");
                     }
                     else
                     {
                         infoArea.appendText("Your GPA is: F\n");
                     }
                 }
                 
            }
        }));
        
        Button buttonStat = new Button("Show Statistics");
        buttonStat.setMaxWidth(Double.MAX_VALUE);
        
        buttonStat.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent e){
                String class1;
                 class1 = score1.getText();
                 String class2;
                 class2 = score2.getText();
                 String class3;
                 class3 = score3.getText();
                 String class4;
                 class4 = score4.getText();
                 
                System.out.println("Show Statistics Button pressed");
                int max = Integer.MIN_VALUE;
                int min = Integer.MAX_VALUE;
                if(class1.isEmpty() || class2.isEmpty() || class3.isEmpty() || class4.isEmpty()){
                     System.out.println("Error:Please fill in all scores for all 4 Classes");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error:Please fill in all scores for all 4 Classes");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                }
                 else if(checkForChar(class1) == false || checkForChar(class2) == false || checkForChar(class3) == false || checkForChar(class4) == false)
                 {
                     System.out.println("Error: A Character has been entered in as a score!");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error: A Character has been entered in as a score!");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                 }
                 else if(getNum(class1) < 0 || getNum(class1) > 100 || getNum(class2) < 0 || getNum(class2) > 100 || getNum(class3) < 0 || getNum(class3) > 100 || getNum(class4) < 0 || getNum(class4) > 100){
                     System.out.println("Error: A score was entered that is outside of the range of 0 to 100");
                     //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("Error: A score was entered that is outside of the range of 0 to 100");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                 }
                 else{
                     
                        if(getNum(class1) > max){
                            max = getNum(class1);
                        }
                        if(getNum(class1) < min){
                            min = getNum(class1);
                        }
                        if(getNum(class2) > max){
                            max = getNum(class2);
                        }
                        if(getNum(class2) < min){
                            min = getNum(class2);
                        }
                        if(getNum(class3) > max){
                    max = getNum(class3);
                        }
                        if(getNum(class3) < min){
                            min = getNum(class3);
                        }
                        if(getNum(class4) > max){
                            max = getNum(class4);
                        }
                        if(getNum(class4) < min){
                            min = getNum(class4);
                        }
                        infoArea.appendText("Your highest score is: " + max + "\n");
                        infoArea.appendText("Your lowest score is: " + min + "\n");
                 }
            }
        });
        
        Button buttonAlert = new Button("Alert");
        buttonAlert.setMaxWidth(Double.MAX_VALUE);
        
        buttonAlert.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent e){
                String data = infoArea.getText().trim();
                if(data.equals("")){
                    //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText("There is nothing to display");
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                }
                else{
                    //code used from https://www.educba.com/javafx-alert/
                     alert.setContentText(data);
                     alert.showAndWait();
                     //end of code used from https://www.educba.com/javafx-alert/
                }
            }
        });
        
        Button buttonClear = new Button("Clear All");
        buttonClear.setMaxWidth(Double.MAX_VALUE);
        
        buttonClear.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent e){
                System.out.println("Clear All button pressed");
                //referenced from https://stackoverflow.com/questions/24473427/clear-textfield-using-button-java
                score1.setText("");
                score2.setText("");
                score3.setText("");
                score4.setText("");
                infoArea.setText("");
                //end of reference https://stackoverflow.com/questions/24473427/clear-textfield-using-button-java
            }
        });
        
        //this code referenced from https://docs.oracle.com/javafx/2/layout/size_align.htm
        VBox vBoxButtons = new VBox();
        vBoxButtons.setSpacing(10);
        vBoxButtons.setAlignment(Pos.CENTER);
        root.add(vBoxButtons,0,6,2,1);
        vBoxButtons.getChildren().addAll(buttonGPA,buttonStat,buttonAlert,buttonClear);
        
        //end of code used from https://docs.oracle.com/javafx/2/layout/size_align.htm
        
        
        
        //root.setGridLinesVisible(true);
        
        Scene scene = new Scene(root,width,height);
        primaryStage.setScene(scene);
        primaryStage.setTitle(title);
        primaryStage.show();
        
    }
    boolean checkForChar(String s){
        //reference from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
        for(int i = 0;i < s.length();i++){
            if(Character.isLetter(s.charAt(i))){
                return false;
            } 
        }
        return true;
        //end of code referenced from https://kodejava.org/how-do-i-check-if-a-character-representing-a-number/
    }
    int getNum(String s){
        //referenced from https://mkyong.com/java/java-convert-string-to-int/
        int i = Integer.parseInt(s);
        //end of reference from https://mkyong.com/java/java-convert-string-to-int/
        return i;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
